# Attention
This is work in progress of the KnownUser library (V3) for Magento v.2. 
Use at own risk.